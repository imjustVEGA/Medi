namespace MediVax
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void cartilla_Click(object sender, EventArgs e)
        {
            Cartilla form1 = new Cartilla();
            form1.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        protected void btnRecomendaciones_Click(object sender, EventArgs e)
        {

        }
        protected void btnMenu_Click(object sender, EventArgs e)
        {

        }
        protected void button3_Click(object sender, EventArgs e)
        {
            // L�gica del evento
        }
        protected void button4_Click(object sender, EventArgs e)
        {
            // L�gica del evento
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
